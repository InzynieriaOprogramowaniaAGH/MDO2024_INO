#ifndef IRSSI_IRC_FLOOD_FLOOD_H
#define IRSSI_IRC_FLOOD_FLOOD_H

void flood_init(void);
void flood_deinit(void);

#endif
