Dependencies:

- libutf8proc-dev
- libcrypt1
