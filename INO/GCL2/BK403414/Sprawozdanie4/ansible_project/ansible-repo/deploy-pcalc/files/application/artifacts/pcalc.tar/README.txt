== Dependencies ==
-> libncurses5
-> libncursesw5

== Setup ==
Add to .bashrc:
alias <PATH_TO_PCALC> pcalc
