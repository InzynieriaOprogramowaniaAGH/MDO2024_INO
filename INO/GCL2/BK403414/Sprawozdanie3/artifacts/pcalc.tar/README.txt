== Dependencies ==
"Programmer calculator" does not require to install any addidtional depedencies than default ubuntu packages. 

== Setup ==
Add to .bashrc:
alias <PATH_TO_PCALC> pcalc
