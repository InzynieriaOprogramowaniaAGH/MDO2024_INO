void irssi_set_dirty(void)
{
}

void irssi_redraw(void)
{
}

int quitting = 0;
