#include "module.h"

#undef MODULE_NAME
#define MODULE_NAME "fe-common/perl"
