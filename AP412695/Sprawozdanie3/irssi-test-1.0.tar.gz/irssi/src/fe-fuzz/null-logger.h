#ifndef IRSSI_FE_FUZZ_NULL_LOGGER_H
#define IRSSI_FE_FUZZ_NULL_LOGGER_H

void g_log_set_null_logger(void);

#endif
