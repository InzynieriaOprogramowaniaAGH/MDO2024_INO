#include <irssi/src/common.h>
#include <irssi/src/fe-text/term.h>

#define MODULE_NAME "fe-text"

extern int quitting;
void irssi_redraw(void);
void irssi_set_dirty(void);
